package com.example.kitkatlive

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {}