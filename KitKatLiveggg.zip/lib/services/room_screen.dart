import 'package:flutter/material.dart';
import 'room_service.dart';

class RoomScreen extends StatefulWidget {
  final String currentUserId;

  const RoomScreen({Key? key, required this.currentUserId}) : super(key: key);

  @override
  State<RoomScreen> createState() => _RoomScreenState();
}

class _RoomScreenState extends State<RoomScreen> {
  final TextEditingController _roomNameController = TextEditingController();
  final TextEditingController _roomIdController = TextEditingController();
  final RoomService _roomService = RoomService();

  String? _joinedRoomId;
  String? _error;

  void _createRoom() async {
    String roomName = _roomNameController.text.trim();
    if (roomName.isEmpty) {
      setState(() => _error = 'يرجى إدخال اسم الغرفة');
      return;
    }
    String newRoomId = await _roomService.createRoom(name: roomName, creatorId: widget.currentUserId);
    setState(() {
      _joinedRoomId = newRoomId;
      _error = null;
    });
  }

  void _joinRoom() async {
    String roomId = _roomIdController.text.trim();
    if (roomId.isEmpty) {
      setState(() => _error = 'يرجى إدخال معرف الغرفة');
      return;
    }
    bool success = await _roomService.joinRoom(roomId: roomId, userId: widget.currentUserId);
    if (success) {
      setState(() {
        _joinedRoomId = roomId;
        _error = null;
      });
    } else {
      setState(() => _error = 'الغرفة غير موجودة');
    }
  }

  @override
  void dispose() {
    _roomNameController.dispose();
    _roomIdController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('الغرف'),
      ),
      body: Padding(
        padding: EdgeInsets.all(16),
        child: _joinedRoomId == null
            ? Column(
                children: [
                  TextField(
                    controller: _roomNameController,
                    decoration: InputDecoration(labelText: 'اسم الغرفة الجديدة'),
                  ),
                  ElevatedButton(
                    onPressed: _createRoom,
                    child: Text('إنشاء غرفة'),
                  ),
                  Divider(),
                  TextField(
                    controller: _roomIdController,
                    decoration: InputDecoration(labelText: 'معرف الغرفة للانضمام'),
                  ),
                  ElevatedButton(
                    onPressed: _joinRoom,
                    child: Text('انضم إلى غرفة'),
                  ),
                  if (_error != null)
                    Padding(
                      padding: EdgeInsets.only(top: 20),
                      child: Text(
                        _error!,
                        style: TextStyle(color: Colors.red),
                      ),
                    )
                ],
              )
            : StreamBuilder<Room>(
                stream: _roomService.roomStream(_joinedRoomId!),
                builder: (context, snapshot) {
                  if (snapshot.connectionState == ConnectionState.waiting) {
                    return Center(child: CircularProgressIndicator());
                  }
                  if (!snapshot.hasData) {
                    return Center(child: Text('لم يتم العثور على الغرفة'));
                  }
                  final room = snapshot.data!;
                  return Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('الغرفة: ${room.name}', style: TextStyle(fontSize: 24)),
                      SizedBox(height: 10),
                      Text('عدد الأعضاء: ${room.members.length}'),
                      SizedBox(height: 20),
                      Expanded(
                        child: ListView.builder(
                          itemCount: room.members.length,
                          itemBuilder: (context, index) {
                            return ListTile(
                              title: Text('عضو: ${room.members[index]}'),
                            );
                          },
                        ),
                      ),
                      ElevatedButton(
                        onPressed: () {
                          setState(() {
                            _joinedRoomId = null;
                          });
                        },
                        child: Text('الخروج من الغرفة'),
                      ),
                    ],
                  );
                },
              ),
      ),
    );
  }
}